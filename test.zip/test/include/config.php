<?php
$conn=mysqli_connect("localhost","root","","registration") or die("cannot connect to localhost");



?>