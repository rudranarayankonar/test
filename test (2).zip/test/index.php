<?php
include("include/config.php");
session_start();
?>
<?php

if(isset($_SESSION['usr']))
{
header("location:profile.php");
}
?>


<?php
if(isset($_POST['btn1']))
{
    extract($_POST);
    $q2="select * from `user` where `email`='$email' and `password`='$password'";
    $e2=mysqli_query($conn,$q2);
    if(mysqli_num_rows($e2)>0)
    {
        $_SESSION['usr']=$email;
      header("location:profile.php");
     
    }
    else{
        $msg="invalid login details";

    }
}
 else if(isset($_POST['btn2']))
{
    extract($_POST);
    $q3="select * from `user` where `email`='$email'";
    $e3=mysqli_query($conn,$q3);
    if(mysqli_num_rows($e3)>0)
    {
     $msg="email number already exist";
    }
    else{
        $q4="INSERT INTO `user`( `name`, `email`, `phone`, `password`) VALUES ('$name','$email','$phone','$password')";
        $e4=mysqli_query($conn,$q4);
       
        if($e4)
        {
          $msg="registration successfully";
        }
        else{
            $msg="registration failed";
        }

    }
}
else{
    $msg="";
}

?>
<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <style>
     .carousel-item>img{width:100%;height:400px;}
  </style>
  <body>
    <div class="container-fluid">
        <nav class="navbar navbar-expand-sm navbar-light bg-success">
            <a class="navbar-brand" href="#">TEST</a>
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="#">Action 1</a>
                            <a class="dropdown-item" href="#">Action 2</a>
                        </div>
                    </li>
                </ul>
               <!-- Button trigger modal -->
               <button type="button" class="btn btn-primary btn-sm mr-3" data-toggle="modal" data-target="#modelLogin">
                 LOGIN
               </button>
               <button type="button" class="btn btn-primary btn-sm mr-3" data-toggle="modal" data-target="#modelSignup">
                 REGISTRATION
               </button>
            </div>
        </nav>
        <?php 
        if($msg!="")
            {
        ?>
      <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            <span class="sr-only">Close</span>
        </button>
        <strong>Alert !</strong> <?php echo"$msg"; ?>.
      </div>
      <?php
            }
      ?> 


        <div id="carouselId" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselId" data-slide-to="0" class="active"></li>
                <li data-target="#carouselId" data-slide-to="1"></li>
                <li data-target="#carouselId" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img src="image/food1.jpg" data-src="holder.js/900x500/auto/#777:#555/text:First slide" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img src="image/food2.jpg" data-src="holder.js/900x500/auto/#666:#444/text:Second slide" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img src="image/food3.jpg" data-src="holder.js/900x500/auto/#666:#444/text:Third slide" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselId" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselId" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
</div>

                <!-- Modal -->
            <div class="modal fade" id="modelLogin" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">LOGIN </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                        </div>
                        <div class="modal-body">
                           
                        <form action="" method="post">
                                 
                        <div class="form-group text-dark">
                              <label for="">EMAIL</label>
                              <input type="email"
                                class="form-control" name="email" id="email" aria-describedby="helpId" placeholder="please enterypur email">
                             
                            </div>
                            <div class="form-group text-dark">
                                <label for="">PASSWORD</label>
                                <input type="password"
                                  class="form-control" name="password" id="password" aria-describedby="helpId" placeholder="please enter your password">
                                
                                </div>
                             <div class="form-check form-check-inline">
                            
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="" id="" value="checkedValue">REMEMBER ME
                                </label>
                             </div>
                                <div>
                              <button type="submit" name="btn1" class="btn-sm btn-success">Login</button>
                              <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#modelSignup" data-dismiss="modal">New User?</button>
                                </div>
                            </form>
                            </div>
                           
                        <div class="modal-footer ">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            
                        </div>
                    </div>
                </div>
            </div>

              <!-- Modal2 -->
              <div class="modal fade" id="modelSignup" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">REGISTRATION</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                        </div>
                        <div class="modal-body">
                           
                        <form action="" method="post">
                        <div class="form-group ">
                              <label for="">NAME</label>
                              <input type="name"
                                class="form-control" name="name" id="name" Required aria-describedby="helpId" placeholder="please enterypur name">
                             
                            </div>      
                        <div class="form-group ">
                              <label for="">EMAIL</label>
                              <input type="email"
                                class="form-control" name="email" id="email"  Required aria-describedby="helpId" placeholder="please enterypur email">
                             
                            </div>
                            <div class="form-group ">
                              <label for="">PHONE</label>
                              <input type="phone"
                                class="form-control" name="phone" id="phone"  Required aria-describedby="helpId" placeholder="please enterypur phone">
                             
                            </div>
                            <div class="form-group text-dark">
                                <label for="">PASSWORD</label>
                                <input type="password"
                                  class="form-control" name="password" id="password"  Required aria-describedby="helpId" placeholder="please enter your password">
                                
                                </div>
                            
                                <div>
                              <button type="submit" name="btn2" class="btn-sm btn-success">registration</button>
                             
                                </div>
                            </form>
                            </div>
                           
                        <div class="modal-footer ">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            
                        </div>
                    </div>
                </div>
            </div>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>